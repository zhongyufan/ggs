const x = 100;
let y = 200;
const fn = () => {
	console.log(1234);
}